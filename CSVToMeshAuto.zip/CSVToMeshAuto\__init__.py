# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "CSVToMeshAuto",
    "author": "Auto-detect fork",
    "description": "将 RenderDoc 导出的 CSV 转换为网格（自动检测位置和 UV 列）",
    "blender": (2, 80, 0),
    "version": (2, 0, 0),
    "location": "View3D > Tool > CSVToMeshAuto",
    "warning": "",
    "category": "Add Mesh",
}

import bpy
from bpy.types import Context
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, IntProperty
from bpy_extras.io_utils import ImportHelper

import csv
import os


# ============================================================================
# Column detection
# ============================================================================

def _col_has(name, *keywords):
    lo = name.lower().strip()
    return any(kw in lo for kw in keywords)


def detect_columns(filepath):
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        header = [c.strip() for c in next(reader)]

    n = len(header)

    # --- position columns ---
    pos_start = None
    for i in range(n - 2):
        if _col_has(header[i], "position", "sv_position"):
            pos_start = i
            break

    if pos_start is None:
        for i in range(n - 2):
            if "texcoord0" in header[i].lower():
                pos_start = i
                break

    if pos_start is None and n >= 5:
        pos_start = 2

    # --- UV channels ---
    uv_channels = []
    seen = set()
    for i in range(n):
        if pos_start is not None and pos_start <= i < pos_start + 3:
            continue
        col = header[i].lower()
        if "texcoord" in col or col.startswith("uv"):
            base = col.rstrip(".xyzwuv")
            digits = ""
            for ch in reversed(base):
                if ch.isdigit():
                    digits = ch + digits
                else:
                    break
            key = base[:len(base)-len(digits)] + digits if digits else base
            if key not in seen:
                seen.add(key)
                uv_channels.append((i, header[i]))

    return {
        "pos_start": pos_start,
        "uv_channels": uv_channels,
        "header": header,
        "col_count": n,
    }


# ============================================================================
# Validation
# ============================================================================

def validate_csv(filepath, pos_start, uv_index):
    errors = []
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        hdr = next(reader)
        rows = list(reader)

    if not rows:
        return ["CSV 文件没有数据行"]

    row_count = len(rows)
    col_count = len(hdr)

    if row_count % 3 != 0:
        errors.append(
            "数据行数 {} 不是 3 的倍数，无法构成完整三角形".format(row_count)
        )

    if pos_start is None or pos_start + 2 >= col_count:
        errors.append("未找到顶点位置列（需要连续 3 列 X/Y/Z）")
    else:
        try:
            r0 = rows[0]
            float(r0[pos_start])
            float(r0[pos_start + 1])
            float(r0[pos_start + 2])
        except (ValueError, IndexError):
            errors.append(
                "位置列 {}-{} 不是数字".format(pos_start, pos_start + 2)
            )

    if uv_index is None or uv_index + 1 >= col_count:
        errors.append("未找到 UV 列（需要连续 2 列 U/V）")
    else:
        try:
            r0 = rows[0]
            float(r0[uv_index])
            float(r0[uv_index + 1])
        except (ValueError, IndexError):
            errors.append("UV 列 {}-{} 不是数字".format(uv_index, uv_index + 1))

    if col_count < 5:
        errors.append("列数太少（{}），至少需要 5 列".format(col_count))

    return errors


# ============================================================================
# Mesh builder
# ============================================================================

def create_mesh(data, pos_start, uv_index, name):
    count = len(data)
    min_id = 65535
    max_id = 0

    wm = bpy.context.window_manager
    total = count + count // 3
    wm.progress_begin(0, total)

    try:
        for i in range(count):
            idx_val = int(data[i][1])
            min_id = min(min_id, idx_val)
            max_id = max(max_id, idx_val)
            if i % 5000 == 0:
                wm.progress_update(i)

        vertex_count = max_id - min_id + 1
        vertices = [(0.0, 0.0, 0.0)] * vertex_count
        uv_data = [(0.0, 0.0)] * vertex_count
        triangles = []

        k = 0
        while k < count:
            tri = [0, 0, 0]
            for i in range(3):
                row = data[k + i]
                idx = int(row[1])
                real_idx = idx - min_id
                tri[i] = real_idx
                vertices[real_idx] = (
                    float(row[pos_start]),
                    float(row[pos_start + 1]),
                    float(row[pos_start + 2]),
                )
                uv_data[real_idx] = (
                    float(row[uv_index]),
                    float(row[uv_index + 1]),
                )
            triangles.append((tri[0], tri[1], tri[2]))
            k += 3
            if k % 3000 == 0:
                wm.progress_update(count + k // 3)
    finally:
        wm.progress_end()

    mesh_data = bpy.data.meshes.new(name)
    mesh_data.from_pydata(vertices, [], triangles)
    mesh_data.update()

    uv_layer = mesh_data.uv_layers.new(name="UVMap")
    for loop in mesh_data.loops:
        uv_layer.data[loop.index].uv = uv_data[loop.vertex_index]

    return mesh_data


# ============================================================================
# File reader
# ============================================================================

def read_csv_file(filepath):
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = [row for row in reader]
    return header, rows


# ============================================================================
# Properties
# ============================================================================

class CSVTOOL_Properties(bpy.types.PropertyGroup):
    auto_detect: BoolProperty(
        name="自动检测",
        default=True,
        description="根据 CSV 表头自动定位位置列和 UV 列",
    )
    pos_start: IntProperty(
        name="位置列",
        default=2,
        min=0,
        description="顶点 X 列的索引（关闭自动检测时生效）",
    )
    uv_index: IntProperty(
        name="UV 列",
        default=5,
        min=0,
        description="UV U 列的索引（关闭自动检测时生效）",
    )


# ============================================================================
# Operator
# ============================================================================

class CSVTOOL_OT_import(Operator, ImportHelper):
    bl_idname = "csv_to_mesh_auto.import_csv"
    bl_label = "导入 CSV"
    bl_description = "从 RenderDoc 导出的 CSV 文件创建网格"
    bl_options = {"PRESET", "UNDO"}

    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv", options={"HIDDEN"})

    def execute(self, context):
        filepath = self.filepath
        props = context.scene.csv_to_mesh_auto_tool

        # ---- detect ----
        det = detect_columns(filepath)
        pos_start = det["pos_start"]
        uv_channels = det["uv_channels"]
        header = det["header"]

        if props.auto_detect:
            if pos_start is not None:
                props.pos_start = pos_start
            if uv_channels:
                props.uv_index = uv_channels[0][0]
            self.report(
                {"INFO"},
                "检测：位置列={}  UV列={}".format(props.pos_start, props.uv_index),
            )
        else:
            pos_start = props.pos_start
            # uv_index set below

        uv_index = props.uv_index

        # ---- validate ----
        errors = validate_csv(filepath, pos_start, uv_index)
        if errors:
            for e in errors:
                self.report({"ERROR"}, e)
            return {"CANCELLED"}

        # ---- read ----
        try:
            _h, data = read_csv_file(filepath)
        except Exception as e:
            self.report({"ERROR"}, "读取文件失败：{}".format(e))
            return {"CANCELLED"}

        # ---- build ----
        filename = os.path.basename(filepath)
        mesh_name = os.path.splitext(filename)[0]
        tri_count = len(data) // 3

        print("CSVToMeshAuto: {} rows, {} triangles".format(len(data), tri_count))
        print("  Pos: [{},{},{}]  UV: [{},{}]".format(
            pos_start, pos_start+1, pos_start+2, uv_index, uv_index+1))

        try:
            mesh_data = create_mesh(data, pos_start, uv_index, mesh_name)
        except Exception as e:
            self.report({"ERROR"}, "生成网格失败：{}".format(e))
            return {"CANCELLED"}

        obj = bpy.data.objects.new(mesh_name, mesh_data)
        context.collection.objects.link(obj)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        self.report({"INFO"}, "导入成功：{} 个三角形".format(tri_count))
        return {"FINISHED"}


# ============================================================================
# Panel
# ============================================================================

class CSVTOOL_PT_main(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "CSVToMeshAuto"
    bl_label = "CSV 转网格"

    def draw(self, context):
        props = context.scene.csv_to_mesh_auto_tool
        layout = self.layout

        box = layout.box()
        box.label(text="检测设置", icon="SETTINGS")
        box.prop(props, "auto_detect")

        row = box.row(align=True)
        row.prop(props, "pos_start")
        row.prop(props, "uv_index")
        if props.auto_detect:
            row.enabled = False

        layout.separator()
        op = layout.operator(
            "csv_to_mesh_auto.import_csv",
            text="导入 CSV",
            icon="IMPORT",
        )


# ============================================================================
# Registration
# ============================================================================

classes = [CSVTOOL_Properties, CSVTOOL_OT_import, CSVTOOL_PT_main]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.csv_to_mesh_auto_tool = bpy.props.PointerProperty(
        type=CSVTOOL_Properties
    )
    print("CSVToMeshAuto v2.0 已加载")


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.csv_to_mesh_auto_tool
    print("CSVToMeshAuto 已卸载")


if __name__ == "__main__":
    register()
